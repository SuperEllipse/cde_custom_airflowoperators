This is a simple example package. You can use
refer to :" [here](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

Demo Script:
Delete earlier Package version in dist
Change the .toml file for new version

python3 -m build

python3 -m twine upload --repository testpypi dist/*
user name : __token__
pypi-AgENdGVzdC5weXBpLm9yZwIkYmU2ZGRmZjEtNDQ5ZS00YWUzLWFjNzAtZTE1MzdjZmJlZmQ5AAIqWzMsIjJhNGYyY2ZjLTllNGEtNDViMi04NWM2LTIyZmE1ZjNhM2E1NyJdAAAGIDTnHBkapxZhUQJqHdNYKQK6YrvqXu5bpNAkMvEhap-6
pypi-AgENdGVzdC5weXBpLm9yZwIkYjhiNDlhMmUtNDY3Ny00MGM1LThkMmEtMDg2ZDc2OTliYjk0AAIqWzMsIjJhNGYyY2ZjLTllNGEtNDViMi04NWM2LTIyZmE1ZjNhM2E1NyJdAAAGIADMZUYmfCKpaofN21bRY0i_4yyfEv-IlMxMh57nBCO3

SHOW THE Package in Pypi : https://test.pypi.org/project/example-package-superellipse/#history


# validate in the python3 that the package works 
from custom_airflow_operator_superellipse import arithmetic_operator

cde resource create --name custom-pypi-02  --type python-env --python-version python3 --config-profile dbt-airflow-spark3