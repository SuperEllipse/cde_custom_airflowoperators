from airflow import DAG
from datetime import datetime
from custom_airflow_operator_superellipse.arithmetic_operator import ArithmeticOperator  # Ensure the path is correct

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

with DAG('arithmetic_dag', default_args=default_args, schedule_interval='@daily', catchup=False) as dag:
    task_add = ArithmeticOperator(
        task_id='add_task',
        num1=10,
        num2=5,
        operation='add'
    )

    task_subtract = ArithmeticOperator(
        task_id='subtract_task',
        num1=10,
        num2=5,
        operation='subtract'
    )

    task_multiply = ArithmeticOperator(
        task_id='multiply_task',
        num1=10,
        num2=5,
        operation='multiply'
    )

    task_divide = ArithmeticOperator(
        task_id='divide_task',
        num1=10,
        num2=5,
        operation='divide'
    )

    task_add >> task_subtract >> task_multiply >> task_divide
